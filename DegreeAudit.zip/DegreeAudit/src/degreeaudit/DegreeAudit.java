package degreeaudit;

/**
 * CPSC Degree Audit application.
 * @author CPSC 2740, Spring 2014
 */
public class DegreeAudit {

    public static void main(String[] args) {
        displayWelcomeMessage();
        tnguye91();
        nsoifer();
    }

    public static void displayWelcomeMessage() {
        System.out.println("Hello, World!");
    }
    
    public static void tnguye91() {
        
    }
    
    public static void nsoifer() {
        
    }
}
